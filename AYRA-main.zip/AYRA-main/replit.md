# AYRA - Discord Bot Dashboard

## Overview

AYRA is a Discord bot with a mystical/fantasy persona, featuring a web-based dashboard for monitoring bot statistics and user interactions. The bot is designed as a "Chromatic Progenitor" character named Ayra who responds to Discord messages using OpenAI's GPT-4 for generating in-character responses. The dashboard displays real-time metrics, user leaderboards, and provides a mystical-themed UI experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom mystical dark theme (purple/crimson color palette)
- **Animations**: Framer Motion for page transitions and visual effects
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints defined in shared route contracts with Zod validation
- **Discord Integration**: discord.js library for bot functionality
- **AI Integration**: OpenAI API (via Replit AI Integrations) for generating character responses
- **Voice Support**: @discordjs/voice for voice channel interactions with gTTS for text-to-speech

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Tables**:
  - `known_users`: Tracks Discord users, their affinity levels, and last interactions
  - `memories`: Stores facts/memories associated with users
  - `bot_stats`: Key-value store for bot metrics (interactions, souls count, etc.)
  - `conversations` and `messages`: Chat history storage for AI conversations

### Project Structure
- `/client` - React frontend application
- `/server` - Express backend with Discord bot
- `/shared` - Shared types, schemas, and route definitions between client/server
- `/server/replit_integrations` - Replit AI integration modules (chat, image, batch processing)

### Key Design Decisions
- **Monorepo Structure**: Client and server share types through `/shared` directory, ensuring type safety across the stack
- **Character Identity**: Bot personality defined in `CORE-IDENTITY.md` which is loaded at runtime and injected into AI prompts
- **Real-time Dashboard**: Stats refresh every 10 seconds using React Query's refetchInterval
- **Unified Build**: Single build script compiles both Vite frontend and esbuild backend

## External Dependencies

### Third-Party Services
- **OpenAI API**: GPT-4 for generating in-character responses (configured via `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL`)
- **Discord API**: Bot presence and message handling (requires `DISCORD_BOT_TOKEN`)
- **PostgreSQL**: Primary database (requires `DATABASE_URL`)

### Key NPM Packages
- `discord.js` - Discord bot framework
- `@discordjs/voice` - Voice channel support
- `drizzle-orm` + `drizzle-kit` - Database ORM and migrations
- `openai` - OpenAI API client
- `gtts` - Google Text-to-Speech for voice responses
- `express` - HTTP server framework
- `@tanstack/react-query` - Data fetching and caching
- `framer-motion` - Animation library
- `wouter` - Client-side routing