import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { startBot, getBotStatus } from "./bot";
import fs from "fs";
import path from "path";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Dashboard API
  app.get(api.dashboard.stats.path, async (req, res) => {
    const dbStats = await storage.getStats();
    const botStatus = getBotStatus();
    
    res.json({
      online: botStatus.online,
      totalSouls: dbStats["total_souls"] || 0,
      interactionsToday: dbStats["interactions_today"] || 0,
      etherLatency: botStatus.ping || 0,
    });
  });

  app.get(api.dashboard.leaderboard.path, async (req, res) => {
    const users = await storage.getLeaderboard(10);
    const leaderboard = users.map(u => ({
        username: u.username,
        affinityLevel: u.affinityLevel || 0,
        lastInteraction: u.lastInteraction ? u.lastInteraction.toISOString() : null,
    }));
    res.json(leaderboard);
  });

  app.get(api.dashboard.downloadCore.path, async (req, res) => {
    // Basic implementation: send the current file structure or specific file
    // For simplicity, let's just download the identity file or a dummy zip
    // Replit might block zip generation of the whole project easily in this env without archiver
    // Let's send the CORE-IDENTITY.md for now as a "Core" download
    const filePath = path.join(process.cwd(), "CORE-IDENTITY.md");
    res.download(filePath, "CORE-IDENTITY.md");
  });

  // Start the Discord Bot
  startBot();

  return httpServer;
}
