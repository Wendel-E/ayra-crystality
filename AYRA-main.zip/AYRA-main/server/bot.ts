import { Client, GatewayIntentBits, Partials, ChannelType } from "discord.js";
import { getAyraResponse } from "./openai";
import { storage } from "./storage";
import { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } from "@discordjs/voice";
import gTTS from "gtts";
import fs from "fs";
import path from "path";

// Setup Discord Client
export const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Channel],
});

let isOnline = false;

client.once("ready", () => {
  console.log(`Ayra Online! Logged in as ${client.user?.tag}`);
  isOnline = true;
  storage.updateStat("online_status", 1);
});

client.on("disconnect", () => {
  isOnline = false;
  storage.updateStat("online_status", 0);
});

// Message Handling
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  // Increment interaction stats
  await storage.incrementStat("total_interactions");
  await storage.incrementStat("interactions_today"); // Logic for resetting "today" is simple increment for now

  // Register/Update User
  let user = await storage.getUser(message.author.id);
  if (!user) {
    user = await storage.createUser({
      discordId: message.author.id,
      username: message.author.username,
      affinityLevel: 0,
    });
    await storage.incrementStat("total_souls");
  } else {
    await storage.updateUserLastInteraction(message.author.id);
  }

  // Voice Command: "Ayra, vamos call"
  const contentLower = message.content.toLowerCase();
  if (contentLower.includes("ayra") && (contentLower.includes("vamos call") || contentLower.includes("entra na call") || contentLower.includes("vem call"))) {
    if (message.member?.voice.channel) {
      const connection = joinVoiceChannel({
        channelId: message.member.voice.channel.id,
        guildId: message.guild!.id,
        adapterCreator: message.guild!.voiceAdapterCreator,
      });

      const response = await getAyraResponse(`(O usuário pediu para você entrar na chamada de voz). ${message.content}`, message.author.username);
      message.reply(response);
      
      // Speak the response
      speakResponse(connection, response);
    } else {
      message.reply("Você precisa estar em um canal de voz para que eu possa me juntar, pequena chama.");
    }
    return;
  }

  // Mention or DM handling for Chat
  if (message.mentions.users.has(client.user!.id) || message.channel.type === ChannelType.DM) {
    const cleanContent = message.content.replace(`<@${client.user!.id}>`, "").trim();
    if (!cleanContent) return;

    message.channel.sendTyping();
    const response = await getAyraResponse(cleanContent, message.author.username);
    
    // Split long messages if needed, but for now simple reply
    if (response.length > 2000) {
      message.reply(response.substring(0, 2000));
    } else {
      message.reply(response);
    }

    // Increase affinity slightly
    await storage.updateUserAffinity(message.author.id, 1);
  }
});

// TTS Helper
async function speakResponse(connection: any, text: string) {
  const gtts = new gTTS(text, 'pt');
  const tempFile = path.join(process.cwd(), `temp_tts_${Date.now()}.mp3`);
  
  gtts.save(tempFile, function (err: any, result: any) {
    if(err) { console.error(err); return; }
    
    const player = createAudioPlayer();
    const resource = createAudioResource(tempFile);
    
    player.play(resource);
    connection.subscribe(player);
    
    player.on(AudioPlayerStatus.Idle, () => {
      fs.unlinkSync(tempFile); // Clean up
    });
  });
}

export function startBot() {
  if (!process.env.DISCORD_TOKEN) {
    console.warn("DISCORD_TOKEN not set. Bot will not start.");
    return;
  }
  client.login(process.env.DISCORD_TOKEN).catch(console.error);
}

export function getBotStatus() {
    return {
        online: isOnline,
        ping: client.ws.ping
    }
}
