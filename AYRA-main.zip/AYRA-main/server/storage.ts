import { db } from "./db";
import { knownUsers, memories, botStats, type InsertKnownUser, type InsertMemory } from "@shared/schema";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(discordId: string): Promise<typeof knownUsers.$inferSelect | undefined>;
  createUser(user: InsertKnownUser): Promise<typeof knownUsers.$inferSelect>;
  updateUserAffinity(discordId: string, affinityChange: number): Promise<void>;
  updateUserLastInteraction(discordId: string): Promise<void>;
  getLeaderboard(limit?: number): Promise<typeof knownUsers.$inferSelect[]>;
  
  // Memories
  addMemory(memory: InsertMemory): Promise<void>;
  getMemories(userId: number): Promise<typeof memories.$inferSelect[]>;

  // Stats
  updateStat(metric: string, value: number): Promise<void>;
  incrementStat(metric: string): Promise<void>;
  getStats(): Promise<Record<string, number>>;
}

export class DatabaseStorage implements IStorage {
  async getUser(discordId: string) {
    const [user] = await db.select().from(knownUsers).where(eq(knownUsers.discordId, discordId));
    return user;
  }

  async createUser(user: InsertKnownUser) {
    const [newUser] = await db.insert(knownUsers).values(user).returning();
    return newUser;
  }

  async updateUserAffinity(discordId: string, affinityChange: number) {
    await db
      .update(knownUsers)
      .set({ affinityLevel: sql`${knownUsers.affinityLevel} + ${affinityChange}` })
      .where(eq(knownUsers.discordId, discordId));
  }

  async updateUserLastInteraction(discordId: string) {
    await db
      .update(knownUsers)
      .set({ lastInteraction: new Date() })
      .where(eq(knownUsers.discordId, discordId));
  }

  async getLeaderboard(limit = 10) {
    return db.select().from(knownUsers).orderBy(sql`${knownUsers.affinityLevel} DESC`).limit(limit);
  }

  async addMemory(memory: InsertMemory) {
    await db.insert(memories).values(memory);
  }

  async getMemories(userId: number) {
    return db.select().from(memories).where(eq(memories.userId, userId));
  }

  async updateStat(metric: string, value: number) {
    await db
      .insert(botStats)
      .values({ metric, value })
      .onConflictDoUpdate({
        target: botStats.metric,
        set: { value },
      });
  }

  async incrementStat(metric: string) {
    await db
      .insert(botStats)
      .values({ metric, value: 1 })
      .onConflictDoUpdate({
        target: botStats.metric,
        set: { value: sql`${botStats.value} + 1` },
      });
  }

  async getStats() {
    const stats = await db.select().from(botStats);
    return stats.reduce((acc, stat) => {
      acc[stat.metric] = stat.value || 0;
      return acc;
    }, {} as Record<string, number>);
  }
}

export const storage = new DatabaseStorage();
