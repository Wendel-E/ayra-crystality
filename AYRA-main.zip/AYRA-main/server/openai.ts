import fs from "fs";
import path from "path";
import OpenAI from "openai";

// Read the identity file
const identityPath = path.resolve(process.cwd(), "CORE-IDENTITY.md");
let identityContent = "";
try {
  identityContent = fs.readFileSync(identityPath, "utf-8");
} catch (e) {
  console.error("Could not read CORE-IDENTITY.md, using default.", e);
  identityContent = "You are Ayra, a helpful assistant.";
}

// the integration sets the AI_INTEGRATIONS_OPENAI_API_KEY env var
const openai = new OpenAI({ 
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY || "dummy",
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL
});

export async function getAyraResponse(userMessage: string, userName: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: identityContent + `\n\nUser Name: ${userName}` },
        { role: "user", content: userMessage }
      ],
      temperature: 0.9,
    });

    return response.choices[0].message.content || "...";
  } catch (error) {
    console.error("OpenAI Error:", error);
    return "O Éter está instável... (Erro de conexão com OpenAI)";
  }
}
