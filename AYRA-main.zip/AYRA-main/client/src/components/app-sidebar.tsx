import { Home, Trophy, Download, Flame } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";

const menuItems = [
  {
    title: "Nexus",
    url: "/",
    icon: Home,
  },
  {
    title: "Registro de Almas",
    url: "/leaderboard",
    icon: Trophy,
  },
];

export function AppSidebar() {
  const [location] = useLocation();

  const handleDownload = () => {
    window.location.href = "/api/dashboard/download-core";
  };

  return (
    <Sidebar className="border-r border-white/5 bg-secondary/30 backdrop-blur-xl">
      <SidebarHeader className="p-6 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/40 shadow-[0_0_15px_rgba(157,78,221,0.4)]">
            <Flame className="w-6 h-6 text-primary" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-display font-bold text-white tracking-tight">AYRA</span>
            <span className="text-[10px] text-primary font-mono uppercase tracking-[0.2em]">System Core v3</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent className="p-4">
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs uppercase tracking-widest text-muted-foreground mb-4 px-2">Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="gap-2">
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={location === item.url}
                    className="h-11 transition-all hover:bg-white/5 data-[active=true]:bg-primary/20 data-[active=true]:text-primary"
                  >
                    <Link href={item.url} className="flex items-center gap-3 px-3">
                      <item.icon className="w-5 h-5" />
                      <span className="font-medium">{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-6 border-t border-white/5">
        <Button 
          onClick={handleDownload}
          variant="outline" 
          className="w-full gap-2 border-primary/40 text-primary hover:bg-primary hover:text-white transition-all duration-500 shadow-lg hover:shadow-primary/20"
        >
          <Download className="w-4 h-4" />
          <span>Baixar Núcleo</span>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}