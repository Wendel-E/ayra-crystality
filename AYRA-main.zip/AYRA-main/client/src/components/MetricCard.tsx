import { ReactNode } from "react";
import { motion } from "framer-motion";

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: string;
  delay?: number;
}

export function MetricCard({ title, value, icon, trend, delay = 0 }: MetricCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: "easeOut" }}
      className="glass-panel rounded-xl p-6 relative overflow-hidden group hover:border-primary/50 transition-colors duration-300"
    >
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity duration-300 transform group-hover:scale-110">
        <div className="text-primary w-24 h-24">{icon}</div>
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-2 text-muted-foreground">
          <div className="p-2 rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">
            {icon}
          </div>
          <h3 className="font-medium text-sm tracking-wider uppercase font-display">{title}</h3>
        </div>
        
        <div className="text-3xl font-bold font-mono text-white mt-4 tracking-tight">
          {value}
        </div>
        
        {trend && (
          <p className="text-xs text-primary/80 mt-2 font-medium">
            {trend}
          </p>
        )}
      </div>

      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
    </motion.div>
  );
}
