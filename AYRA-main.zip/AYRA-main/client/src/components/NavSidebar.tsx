import { Link, useLocation } from "wouter";
import { LayoutDashboard, ScrollText, Download, Flame } from "lucide-react";
import { cn } from "@/lib/utils";
import { useDownloadCore } from "@/hooks/use-dashboard";

export function NavSidebar() {
  const [location] = useLocation();
  const { download } = useDownloadCore();

  const navItems = [
    { href: "/", label: "Nexus", icon: <LayoutDashboard className="w-5 h-5" /> },
    { href: "/leaderboard", label: "Registro de Almas", icon: <ScrollText className="w-5 h-5" /> },
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-64 glass-panel border-r border-white/5 z-50 flex flex-col">
      <div className="p-8 flex flex-col items-center border-b border-white/5 bg-black/20">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-purple-900 flex items-center justify-center mb-4 shadow-lg shadow-primary/20 border border-primary/30">
          <Flame className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-primary/70 bg-clip-text text-transparent">
          AYRA
        </h1>
        <p className="text-xs text-muted-foreground mt-1 uppercase tracking-widest font-mono">
          System Core v3
        </p>
      </div>

      <nav className="flex-1 p-4 space-y-2 mt-4">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 cursor-pointer group",
                location === item.href
                  ? "bg-primary/20 text-white shadow-md shadow-primary/5 border border-primary/20"
                  : "text-muted-foreground hover:text-white hover:bg-white/5"
              )}
            >
              <span className={cn(
                "transition-colors duration-300",
                location === item.href ? "text-primary-foreground" : "text-muted-foreground group-hover:text-primary"
              )}>
                {item.icon}
              </span>
              <span className="font-medium tracking-wide font-display text-sm">
                {item.label}
              </span>
              {location === item.href && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_currentColor]" />
              )}
            </div>
          </Link>
        ))}
      </nav>

      <div className="p-6 border-t border-white/5 bg-black/20">
        <button
          onClick={download}
          className="w-full group relative px-4 py-3 rounded-lg overflow-hidden border border-white/10 bg-white/5 hover:border-primary/50 transition-all duration-300"
        >
          <div className="absolute inset-0 bg-primary/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          <div className="relative flex items-center justify-center gap-2 text-sm font-medium text-white">
            <Download className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform duration-300" />
            <span>Baixar Núcleo</span>
          </div>
        </button>
        <p className="text-[10px] text-center text-muted-foreground mt-4 font-mono opacity-50">
          PROTOC: CROMÁTICA_3
        </p>
      </div>
    </aside>
  );
}
