import { motion } from "framer-motion";

interface StatusOrbProps {
  online: boolean;
  size?: "sm" | "md" | "lg";
}

export function StatusOrb({ online, size = "md" }: StatusOrbProps) {
  const sizeClasses = {
    sm: "w-3 h-3",
    md: "w-6 h-6",
    lg: "w-12 h-12",
  };

  const glowColor = online ? "rgb(34, 197, 94)" : "rgb(220, 38, 38)";

  return (
    <div className="relative flex items-center justify-center">
      <motion.div
        className={`${sizeClasses[size]} rounded-full bg-current relative z-10`}
        style={{ color: glowColor }}
        animate={{
          boxShadow: [
            `0 0 10px ${glowColor}`,
            `0 0 20px ${glowColor}`,
            `0 0 10px ${glowColor}`,
          ],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      {online && (
        <motion.div
          className={`absolute ${sizeClasses[size]} rounded-full bg-current opacity-50`}
          style={{ color: glowColor }}
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.5, 0, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeOut",
          }}
        />
      )}
    </div>
  );
}
