import { Layout } from "@/components/Layout";
import { MetricCard } from "@/components/MetricCard";
import { StatusOrb } from "@/components/StatusOrb";
import { useDashboardStats } from "@/hooks/use-dashboard";
import { Users, Activity, Zap, Server } from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { data: stats, isLoading, isError } = useDashboardStats();

  if (isLoading) {
    return (
      <Layout>
        <div className="flex h-[50vh] items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-muted-foreground font-mono animate-pulse">Sincronizando com o Éter...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (isError || !stats) {
    return (
      <Layout>
        <div className="p-8 border border-destructive/50 bg-destructive/10 rounded-xl text-center">
          <h2 className="text-xl text-destructive font-display mb-2">Falha na Conexão Arcana</h2>
          <p className="text-muted-foreground">Não foi possível estabelecer contato com o núcleo da Ayra.</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-12">
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-1">Painel Nexus</h2>
          <p className="text-muted-foreground">Visão geral dos sistemas arcanos</p>
        </div>
        
        <div className="glass-panel px-6 py-3 rounded-full flex items-center gap-4 border border-white/10">
          <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Status do Sistema</span>
          <div className="h-4 w-px bg-white/10" />
          <div className="flex items-center gap-2">
            <StatusOrb online={stats.online} size="sm" />
            <span className={`font-mono font-bold ${stats.online ? "text-green-400" : "text-red-400"}`}>
              {stats.online ? "ONLINE" : "OFFLINE"}
            </span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <MetricCard
          title="Almas Observadas"
          value={stats.totalSouls}
          icon={<Users className="w-6 h-6" />}
          trend="Total de membros"
          delay={0.1}
        />
        <MetricCard
          title="Interações Hoje"
          value={stats.interactionsToday}
          icon={<Activity className="w-6 h-6" />}
          trend="Comandos executados"
          delay={0.2}
        />
        <MetricCard
          title="Latência do Éter"
          value={`${stats.etherLatency}ms`}
          icon={<Zap className="w-6 h-6" />}
          trend="Ping da API"
          delay={0.3}
        />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-8 glass-panel rounded-2xl p-8 border border-white/5 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Server className="w-64 h-64 text-white" />
        </div>
        
        <h3 className="text-xl font-display font-bold mb-4 relative z-10">Console do Sistema</h3>
        <div className="bg-black/40 rounded-lg p-4 font-mono text-sm text-green-400/80 h-48 overflow-y-auto border border-white/5 relative z-10 shadow-inner">
          <p className="mb-1"><span className="text-muted-foreground">[{new Date().toLocaleTimeString()}]</span> Iniciando protocolo de interface...</p>
          <p className="mb-1"><span className="text-muted-foreground">[{new Date().toLocaleTimeString()}]</span> Conexão segura estabelecida.</p>
          <p className="mb-1"><span className="text-muted-foreground">[{new Date().toLocaleTimeString()}]</span> Carregando módulos de personalidade...</p>
          <p className="mb-1"><span className="text-muted-foreground">[{new Date().toLocaleTimeString()}]</span> <span className="text-primary">Módulo Cromático carregado com sucesso.</span></p>
          {stats.online && (
            <p className="mb-1 animate-pulse"><span className="text-muted-foreground">[{new Date().toLocaleTimeString()}]</span> Monitorando canais de voz...</p>
          )}
        </div>
      </motion.div>
    </Layout>
  );
}
