import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background bg-grid-white/[0.02]">
      <Card className="w-full max-w-md mx-4 glass-panel border-destructive/20">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2">
            <AlertCircle className="h-8 w-8 text-destructive" />
            <h1 className="text-2xl font-display font-bold text-white">404 Vazio</h1>
          </div>

          <p className="mt-4 text-sm text-muted-foreground">
            Você vagou para uma região do éter que não existe.
          </p>

          <div className="mt-8">
            <Link href="/" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 w-full">
              Retornar ao Nexus
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
