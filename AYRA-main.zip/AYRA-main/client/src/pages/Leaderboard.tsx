import { Layout } from "@/components/Layout";
import { useLeaderboard } from "@/hooks/use-dashboard";
import { ScrollText, Trophy, Clock, Search } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";

export default function Leaderboard() {
  const { data: users, isLoading } = useLeaderboard();
  const [search, setSearch] = useState("");

  const filteredUsers = users?.filter(u => 
    u.username.toLowerCase().includes(search.toLowerCase())
  ) || [];

  return (
    <Layout>
      <header className="mb-12">
        <h2 className="text-3xl font-display font-bold text-white mb-2 flex items-center gap-3">
          <ScrollText className="text-primary" />
          Registro de Almas
        </h2>
        <p className="text-muted-foreground">
          Mortais que demonstraram maior afinidade com a Progenitora.
        </p>
      </header>

      <div className="glass-panel rounded-2xl border border-white/5 overflow-hidden flex flex-col min-h-[600px]">
        {/* Toolbar */}
        <div className="p-6 border-b border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4 bg-black/20">
          <div className="relative w-full sm:w-72 group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <input 
              type="text" 
              placeholder="Buscar mortal..." 
              className="w-full bg-black/40 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all placeholder:text-muted-foreground/50"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="text-xs font-mono text-muted-foreground uppercase tracking-widest">
            {filteredUsers.length} Registros Encontrados
          </div>
        </div>

        {/* Table Content */}
        <div className="flex-1 overflow-x-auto">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-64 gap-4">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              <p className="text-sm text-muted-foreground font-mono">Lendo pergaminhos antigos...</p>
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
              <p>Nenhuma alma encontrada com este nome.</p>
            </div>
          ) : (
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-white/5 text-xs font-display uppercase tracking-wider text-muted-foreground bg-white/[0.02]">
                  <th className="px-6 py-4 font-medium w-24">Rank</th>
                  <th className="px-6 py-4 font-medium">Mortal</th>
                  <th className="px-6 py-4 font-medium text-right">Afinidade</th>
                  <th className="px-6 py-4 font-medium text-right hidden md:table-cell">Última Interação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredUsers.map((user, index) => (
                  <motion.tr 
                    key={user.username}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="group hover:bg-white/[0.03] transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className={`
                        w-8 h-8 rounded-full flex items-center justify-center font-bold font-mono text-sm
                        ${index === 0 ? 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/30' : 
                          index === 1 ? 'bg-slate-400/20 text-slate-400 border border-slate-400/30' :
                          index === 2 ? 'bg-amber-700/20 text-amber-700 border border-amber-700/30' :
                          'bg-white/5 text-muted-foreground'}
                      `}>
                        {index < 3 ? <Trophy className="w-3.5 h-3.5" /> : index + 1}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        {/* Avatar Placeholder with Initials */}
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-purple-900/50 border border-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                          {user.username.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-medium text-white group-hover:text-primary transition-colors">{user.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 font-mono font-bold text-sm">
                        {user.affinityLevel}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right hidden md:table-cell">
                      <div className="flex items-center justify-end gap-2 text-muted-foreground text-sm">
                        <Clock className="w-3 h-3" />
                        {user.lastInteraction ? new Date(user.lastInteraction).toLocaleDateString('pt-BR') : 'Desconhecido'}
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </Layout>
  );
}
