import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useDashboardStats() {
  return useQuery({
    queryKey: [api.dashboard.stats.path],
    queryFn: async () => {
      const res = await fetch(api.dashboard.stats.path, { credentials: "include" });
      if (!res.ok) throw new Error("Falha ao carregar métricas do éter");
      return api.dashboard.stats.responses[200].parse(await res.json());
    },
    refetchInterval: 10000, // Refresh every 10s to keep "live" feel
  });
}

export function useLeaderboard() {
  return useQuery({
    queryKey: [api.dashboard.leaderboard.path],
    queryFn: async () => {
      const res = await fetch(api.dashboard.leaderboard.path, { credentials: "include" });
      if (!res.ok) throw new Error("Falha ao consultar o registro de almas");
      return api.dashboard.leaderboard.responses[200].parse(await res.json());
    },
  });
}

export function useDownloadCore() {
  const download = async () => {
    // Direct navigation for file download
    window.location.href = api.dashboard.downloadCore.path;
  };
  return { download };
}
