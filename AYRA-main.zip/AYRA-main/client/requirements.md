## Packages
framer-motion | Essential for the "mystical" animations and page transitions
recharts | For visualizing bot statistics if needed, though simple cards are requested
lucide-react | Already in base, but emphasizing usage for mystical icons (Flame, Scroll, Activity)
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Cinzel'", "'Playfair Display'", "serif"],
  body: ["'DM Sans'", "sans-serif"],
  mono: ["'Fira Code'", "monospace"],
}
Tailwind Config - extend colors:
colors: {
  mystic: {
    900: "#1a0b2e", // Deep Purple background
    800: "#2d1b4e", // Lighter purple for cards
    500: "#9d4edd", // Primary accent
    100: "#e0aaff", // Text highlight
  },
  crimson: {
    900: "#4a0404", // Dark red background/accents
    500: "#ff0000", // Bright red for wrath/danger
  },
  obsidian: "#050505", // Deep black
}
