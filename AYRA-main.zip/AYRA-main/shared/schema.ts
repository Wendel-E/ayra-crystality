import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Mapped to "usuarios_conhecidos"
export const knownUsers = pgTable("known_users", {
  id: serial("id").primaryKey(),
  discordId: text("discord_id").notNull().unique(),
  username: text("username").notNull(),
  affinityLevel: integer("affinity_level").default(0),
  lastInteraction: timestamp("last_interaction").defaultNow(),
});

// Mapped to "memorias_fatos"
export const memories = pgTable("memories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => knownUsers.id),
  fact: text("fact").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Bot Stats for Dashboard
export const botStats = pgTable("bot_stats", {
  id: serial("id").primaryKey(),
  metric: text("metric").notNull().unique(), // e.g., "total_interactions"
  value: integer("value").default(0),
});

// === SCHEMAS ===

export const insertKnownUserSchema = createInsertSchema(knownUsers).omit({ id: true, lastInteraction: true });
export const insertMemorySchema = createInsertSchema(memories).omit({ id: true, createdAt: true });

// === TYPES ===

export type KnownUser = typeof knownUsers.$inferSelect;
export type InsertKnownUser = z.infer<typeof insertKnownUserSchema>;

export type Memory = typeof memories.$inferSelect;
export type InsertMemory = z.infer<typeof insertMemorySchema>;

export type BotStat = typeof botStats.$inferSelect;

// === API TYPES ===

export interface DashboardStats {
  online: boolean;
  totalSouls: number;
  interactionsToday: number;
  etherLatency: number;
}
