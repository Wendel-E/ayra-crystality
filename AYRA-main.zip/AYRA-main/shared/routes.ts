import { z } from 'zod';
import { knownUsers, memories } from './schema';

export const errorSchemas = {
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  dashboard: {
    stats: {
      method: 'GET' as const,
      path: '/api/dashboard/stats',
      responses: {
        200: z.object({
          online: z.boolean(),
          totalSouls: z.number(),
          interactionsToday: z.number(),
          etherLatency: z.number(),
        }),
      },
    },
    leaderboard: {
      method: 'GET' as const,
      path: '/api/dashboard/leaderboard',
      responses: {
        200: z.array(z.object({
          username: z.string(),
          affinityLevel: z.number(),
          lastInteraction: z.string().nullable(), // timestamp as string in JSON
        })),
      },
    },
    downloadCore: {
      method: 'GET' as const,
      path: '/api/dashboard/download-core',
      responses: {
        200: z.any(), // File download
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type DashboardStatsResponse = z.infer<typeof api.dashboard.stats.responses[200]>;
export type LeaderboardResponse = z.infer<typeof api.dashboard.leaderboard.responses[200]>;
